# Javascript OOP Product App
This is a simple Vanilla Javascript Frontend CRUD that uses Object Orientend Programming using Ecmascript 6+ Features.

![](docs/screenshot.png)

# Start the Project
```
npm install
npm start
```

# Project Structure
* `src` is the folder with the source code
